'''

scp -P 29122 -r D:/Afile/exp_3_2_vgg_dlp/stu_upload root@120.236.247.203:/opt/code_chap_2_3/code_chap_2_3_student/exp_3_2_vgg_dlp

ejzvsfhvmain

cd /opt/code_chap_2_3/code_chap_2_3_student
source env.sh
cd exp_3_2_vgg_dlp
python main_exp_3_2.py

'''