# bzpskdwyfjqb

# scp -P 27030 -r C:/Users/A/Desktop/code/exp_2_2_mnist_mlp_dlp_4Layers/stu_upload root@120.236.247.203:/opt/code_chap_2_3/code_chap_2_3_student/exp_2_2_mnist_mlp_dlp
